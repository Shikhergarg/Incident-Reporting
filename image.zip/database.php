<?php
session_start();
$cn=mysql_connect("httpsincident-reportngherokuappcom.000webhostapp.com","incidentreporting","") or die("Could not Connect My Sql");
mysql_select_db("id850321_incidentreporting",$cn)  or die("Could connect to Database");
?>

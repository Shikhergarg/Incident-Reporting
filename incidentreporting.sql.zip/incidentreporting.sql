--
-- Database: `incidentreporting`
--

-- --------------------------------------------------------

--
-- Table structure for table `googlemap`
--

CREATE TABLE `googlemap` (
  `id` int(20) NOT NULL,
  `name` varchar(60) NOT NULL,
  `address` varchar(80) NOT NULL,
  `lat` float(10,6) NOT NULL,
  `lng` float(10,6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `incidentreport`
--

CREATE TABLE `incidentreport` (
  `IncidentId` int(50) NOT NULL,
  `ReporterName` varchar(100) NOT NULL,
  `I_Name` varchar(100) NOT NULL,
  `I_Category` varchar(100) NOT NULL,
  `Location` varchar(500) NOT NULL,
  `Upload` varchar(1000) NOT NULL,
  `Dated` date NOT NULL,
  `Timer` time NOT NULL,
  `Summary` varchar(1000) DEFAULT NULL,
  `seen` tinyint(1) NOT NULL,
  `Annonymous` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `incidentreport`
--

INSERT INTO `incidentreport` (`IncidentId`, `ReporterName`, `I_Name`, `I_Category`, `Location`, `Upload`, `Dated`, `Timer`, `Summary`, `seen`, `Annonymous`) VALUES
(9, 'kshitiz123', 'test', 'opel', 'test', '', '2017-01-03', '00:00:14', 'TESTING              ', 1, 0),
(10, 'kshitiz123', 'test', 'opel', 'test', '', '2017-01-03', '00:00:14', 'TESTING              ', 1, 0),
(11, 'kshitiz123', 'Medical', 'Doctor', 'test', '', '1999-06-05', '00:00:17', '                  The cat was playing in the garden.\r\n                ', 1, 0),
(12, 'jain', 'Murder', 'Doctor', 'Test', '', '2015-04-05', '00:00:15', '                  you are not alone', 1, 0),
(13, 'shikher12', 'diabetes', 'Doctor', 'delhi', '', '2009-03-02', '07:06:00', 'The cat was playing in the garden.\r\n                ', 1, 0),
(14, 'shikher12', 'kartik got cough', 'Doctor', 'BH2', '', '2017-02-08', '03:03:00', '                  The cat was playing in the garden.\r\n                ', 0, 0),
(15, 'kshitiz123', 'cough', 'Doctor', 'rajasthan', '', '2017-04-03', '20:04:00', '                  cough is encountered', 1, 0),
(16, 'kshitiz123', 'Fracture', 'Doctor', 'jaipur', '', '2017-02-12', '03:12:00', '                  The cat was playing in the garden.\r\n                ', 1, 0),
(17, 'kshitiz123', 'Fracture', 'Doctor', 'jaipur', '', '2017-02-12', '03:12:00', '                  The cat was playing in the garden.\r\n                ', 1, 0),
(18, 'kshitiz123', 'Fracture', 'Doctor', 'jaipur', '', '2017-05-05', '05:05:00', '                  The cat was playing in the garden.\r\n                ', 1, 0),
(19, 'kshitiz123', 'in', 'Doctor', 'loc', '', '0000-00-00', '01:52:21', 'ggdg', 1, 0),
(20, 'kshitiz123', 'Mystery', 'Doctor', 'loc', '', '0000-00-00', '10:56:48', 'fever', 1, 0),
(21, 'kshitiz123', 'Mystery', 'Doctor', 'loc', '', '0000-00-00', '10:57:12', 'murder', 1, 0),
(22, 'kshitiz123', 'jhgj', 'Doctor', 'loc', '', '0000-00-00', '10:57:31', 'hgjhg', 1, 0),
(23, 'kshitiz123', 'dfsaf', 'Doctor', 'loc', '', '0000-00-00', '11:29:03', 'fsdfsd', 1, 0),
(24, 'kshitiz123', 'jaundice', 'Doctor', 'loc', '8602772816_eb1df8c368_b.jpg', '0000-00-00', '11:29:47', 'fever', 1, 0),
(25, 'kshitiz123', 'df', 'Doctor', 'loc', '10622868_775867059146196_13539874845505188_n.jpg', '0000-00-00', '04:28:36', 'afds', 1, 0),
(26, 'kshitiz123', 'Feverr', 'Doctor', 'loc', '', '0000-00-00', '04:30:19', 'rgd', 1, 0),
(27, 'kshitiz123', 'dfsd', 'Doctor', 'loc', '', '0000-00-00', '04:48:02', 'dfgsd', 1, 1),
(28, 'kshitiz123', 'gfdgf', 'Doctor', 'loc', '', '0000-00-00', '04:48:39', 'hfdhdf', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `responder`
--

CREATE TABLE `responder` (
  `Resp_Id` int(20) NOT NULL,
  `Resp_Name` varchar(100) NOT NULL,
  `Category` varchar(100) NOT NULL,
  `Pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `responder`
--

INSERT INTO `responder` (`Resp_Id`, `Resp_Name`, `Category`, `Pass`) VALUES
(1, 'Gaurav', 'Doctor', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(100) NOT NULL,
  `uname` varchar(100) DEFAULT NULL,
  `pass` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `uname`, `pass`, `name`, `email`, `phone`) VALUES
(1, 'kshitiz123', '1234', 'kshitiz gupta', 'kshitiz7gupta@gmail.com', '8739815580'),
(4, 'kartik', '123', 'kartik', '', '22079'),
(5, 'shikher12', '123', 'shikher', '', '123'),
(6, 'kartik3', '1234', 'kartik', '', '67656546475'),
(7, 'ksh', '123', 'kshitiz gupta', '', '8739815580'),
(8, 'jain', '1234', 'kartik', '', '123456'),
(9, 'A', 'A', 'A', '', 'A'),
(10, 'gaurav', '123', 'GAURAV AGARWAL', '', '8739815580'),
(11, 'k', 'k', 'k', '', '56'),
(12, 'kl', 'k', 'k', 'k@gmail.com', '67656546475'),
(13, 'sk', '1', 'Shikher Garg', 'gauravjp50@gmail.com', '9116809985'),
(14, 'skg', '1', 'Shikher Garg', 'gauravjp50@gmail.com', '9116809985'),
(15, 'skg1', '1', 'Shikher Garg', 'gauravjp50@gmail.com', '9116809985');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `googlemap`
--
ALTER TABLE `googlemap`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `incidentreport`
--
ALTER TABLE `incidentreport`
  ADD PRIMARY KEY (`IncidentId`);

--
-- Indexes for table `responder`
--
ALTER TABLE `responder`
  ADD PRIMARY KEY (`Resp_Id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `uname` (`uname`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `googlemap`
--
ALTER TABLE `googlemap`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `incidentreport`
--
ALTER TABLE `incidentreport`
  MODIFY `IncidentId` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `responder`
--
ALTER TABLE `responder`
  MODIFY `Resp_Id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
